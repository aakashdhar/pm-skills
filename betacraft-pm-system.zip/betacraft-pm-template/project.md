# [[PROJECT_NAME]]

**Authority:** Tier 2 — Operational
**Client:** [[CLIENT_NAME]]
**PM:** [[PM_NAME]]
**Status:** 🟢 Green / 🟡 Amber / 🔴 Red
**Phase:** Discovery / Build / QA / Delivery
**Started:** [[TODAY]]
**Target Delivery:** [YYYY-MM-DD]
**Last Updated:** [[TODAY]]

---

## Summary

[2–3 sentences on where the project stands today. Written for a PM reading this at the start of a session. Built by Cowork from sow.md after build-sow is run.]

---

## RAG Reason

[One sentence explaining the current status.]

---

## Team

| Name | Role | Contact |
|---|---|---|
| [[PM_NAME]] | Project Manager | [[PM_EMAIL]] |
| [[CLIENT_NAME]] | Client · Product Owner | [[CLIENT_EMAIL]] |
| [Dev name] | Developer | [contact] |

---

## Code Repository

**Repo:** [github.com/betacraft/[project]]
**Branch:** main
**Local path:** [~/code/[project]]
**Access:** Read-only — PM does not push to this repo

---

## Active Requirements

| ID | Title | Status | Due |
|---|---|---|---|
| — | — | — | — |

---

## Recent Deliveries

| ID | Title | Delivered | Verified |
|---|---|---|---|
| — | — | — | — |

---

## Risks

| Risk | Type | Severity | Since |
|---|---|---|---|
| — | — | — | — |

---

## Notes

[Standing context. Anything Cowork should always factor into responses for this project.]
