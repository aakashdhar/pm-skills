# Client — [[CLIENT_NAME]]

**Authority:** Tier 2 — Operational
**Created:** [[TODAY]]

---

## Contact

| Field | Detail |
|---|---|
| Name | [[CLIENT_NAME]] |
| Email | [[CLIENT_EMAIL]] |
| Slack | [handle] |
| Timezone | [timezone] |
| Communication preference | [Email / Slack / Calls] |

---

## Communication Preferences

[How they like to receive updates. Response time. Any preferences.]

---

## Known Sensitivities

[Anything Cowork must factor in when generating client-facing content.]

---

## Relationship Context

[How long BetaCraft has worked with this client. How the relationship started.]

---

## Notes

[Running observations. Patterns in client behaviour. Anything useful for any PM.]
