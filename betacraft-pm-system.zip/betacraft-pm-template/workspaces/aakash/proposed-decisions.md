# Proposed Decisions — [[PM_NAME]]

**Rule:** Staging area for decisions before they are promoted to shared/DECISIONS.md.
**Promoted by:** Owner review via merge-review skill.
**Never edit shared/DECISIONS.md directly** — propose here first.

> Write draft decisions here. When ready, say "merge review"
> and Cowork will diff against shared/DECISIONS.md, flag conflicts,
> and promote on your approval.

---

## Pending Proposals

<!-- Add proposed decisions below. Format:

### PROP-DEC-001 — [Title]
**Date:** YYYY-MM-DD
**Type:** Technical / Strategic / Commercial / Operational
**Proposed by:** [[PM_NAME]]
**Decision:** [what is being proposed]
**Rationale:** [why]
**Affects:** [REQ-00N / area / N/A]
**Status:** Draft / Ready for review

-->

*No pending proposals.*

---

## Promoted

<!-- Moved to shared/DECISIONS.md — kept here for reference -->

*None yet.*
