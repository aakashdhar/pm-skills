# Session Log — [[PM_NAME]]

**Rule:** Append-only. Never edit existing entries.
**Maintained by:** Cowork — appended automatically at session-end.

> One entry per session. Read by session-start to brief you on last activity.
> Captures what was done AND why — so any PM can reconstruct the reasoning.

---

<!-- SESSION LOG — APPEND BELOW — NEWEST AT BOTTOM -->

## [[TODAY]] — Project initialised

**Work done:**
- Project scaffolded from betacraft-pm-template
- Git repository initialised
- GitHub repo created

**Reasoning:**
- Fresh project start — all files at baseline state

**Decisions logged:** None
**Files committed:** All template files
**Open items:** SOW pending — run "build sow" to start
