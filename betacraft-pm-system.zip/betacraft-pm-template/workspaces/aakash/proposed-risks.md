# Proposed Risks — [[PM_NAME]]

**Rule:** Staging area for risks before they are promoted to shared/HOTSHEET.md.
**Promoted by:** Owner review via merge-review skill.
**Never edit shared/HOTSHEET.md directly** — propose here first.

> Write draft risks and blockers here. When ready, say "merge review"
> and Cowork will diff against shared/HOTSHEET.md, flag conflicts,
> and promote on your approval.

---

## Pending Proposals

<!-- Add proposed risks below. Format:

### PROP-RISK-001 — [Title]
**Date:** YYYY-MM-DD
**Type:** 🔴 Blocking / 🟡 Needs Attention / 🔵 Watching
**Proposed by:** [[PM_NAME]]
**Description:** [what the risk is]
**Impact:** [what happens if unresolved]
**Mitigation:** [what can be done]
**Source:** [transcript / email / observation]
**Status:** Draft / Ready for review

-->

*No pending proposals.*

---

## Promoted

<!-- Moved to shared/HOTSHEET.md — kept here for reference -->

*None yet.*
