# Architecture Overview — [[PROJECT_NAME]]

**Authority:** Tier 2 — Operational
**Inherits from:** `reference/sow.md`
**Last Updated:** [[TODAY]]

---

## System Summary

[Describe the overall system — what it is, what it does, what technologies are involved.]

---

## Stack

| Layer | Technology | Notes |
|---|---|---|
| Frontend | | |
| Backend | | |
| Database | | |
| Hosting | | |

---

## Key Architectural Decisions

*See `shared/DECISIONS.md` for full log.*

| DEC | Decision | Date |
|---|---|---|
| — | — | — |

---

## Diagram

[Add ASCII diagram or link to diagram file here.]
