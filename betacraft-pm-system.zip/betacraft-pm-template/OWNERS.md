# OWNERS — [[PROJECT_NAME]]

> Who owns which folders and who can approve changes to what.
> Created: [[TODAY]]

---

| Area | Owner | Can Approve Changes |
|---|---|---|
| `shared/` | [[PM_NAME]] | Yes — via HITL review |
| `reference/` | [[PM_NAME]] | Yes — with client sign-off for Tier 1 |
| `requirements/` | [[PM_NAME]] | Yes — after HITL review |
| `deliverables/` | [[PM_NAME]] | Yes — after dev confirmation |
| `architecture/technical/` | Dev lead | Yes — with PM awareness |
| `architecture/strategic/` | [[PM_NAME]] | Yes |
| `comms/` | [[PM_NAME]] | Yes |
| `research/` | Any team member | Yes — Tier 3, informs only |
| `workspaces/aakash/` | [[PM_NAME]] | Yes |
| `dashboard.html` | [[PM_NAME]] | Yes — via publish-dashboard skill |

---

## Client Contact

**Name:** [[CLIENT_NAME]]
**Email:** [[CLIENT_EMAIL]]

## PM Contact

**Name:** [[PM_NAME]]
**Email:** [[PM_EMAIL]]
**Organisation:** BetaCraft
