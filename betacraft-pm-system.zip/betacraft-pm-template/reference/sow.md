# Statement of Work — [[PROJECT_NAME]]

**Authority:** Tier 1 — Canonical
**Locked:** [date — set when build-sow skill is approved]
**Signed by:** [[CLIENT_NAME]] · [[PM_NAME]]
**Rule:** Never edit after locking. Raise a Change Order for any scope changes.

> Built by the build-sow skill from your answers.
> Run "build sow" in Cowork to populate this file.

---

[Populated by build-sow skill]
