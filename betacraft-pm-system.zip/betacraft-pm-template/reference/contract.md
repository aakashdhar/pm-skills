# Contract — [[PROJECT_NAME]]

**Authority:** Tier 1 — Canonical
**Rule:** Drop the signed contract here. Never edit.

> Place the signed contract document in this folder.
> If it is a PDF — drop the PDF and reference it here.
> If it is a separate document — summarise key terms below.

---

## Key Terms

**Effective date:** [date]
**MSA reference:** [if applicable]
**Governing law:** [jurisdiction]
**Payment terms:** [terms]

---

[Full contract on file — see attached document]
