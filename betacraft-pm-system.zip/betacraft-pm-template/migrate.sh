#!/bin/bash
# ─────────────────────────────────────────────────
# BetaCraft PM System — migrate.sh
# Upgrades an existing project to the latest system:
# adds Obsidian MCP, wikilinks, frontmatter, new
# skills, and new shared/ files without breaking
# anything that already exists.
#
# Usage:
#   bash migrate.sh
#   or
#   bash migrate.sh ~/Documents/brieflex
# ─────────────────────────────────────────────────

set -e

GREEN='\033[0;32m'
AMBER='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
BLUE='\033[0;34m'
RESET='\033[0m'

TEMPLATE_DIR="$(cd "$(dirname "$0")" && pwd)"
CLAUDE_CONFIG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
TODAY=$(date +%Y-%m-%d)

echo ""
echo -e "${BOLD}BetaCraft PM System — Migrate Existing Project${RESET}"
echo "─────────────────────────────────────────"
echo ""

# ── INPUT ─────────────────────────────────────────

if [ -n "$1" ]; then
  PROJECT_DIR="$1"
else
  read -p "Path to existing project (e.g. ~/Documents/brieflex): " PROJECT_DIR
  PROJECT_DIR="${PROJECT_DIR/#\~/$HOME}"
fi

[ -d "$PROJECT_DIR" ] || {
  echo -e "${RED}Error: $PROJECT_DIR not found.${RESET}"
  exit 1
}

PROJECT_SLUG=$(basename "$PROJECT_DIR")
echo -e "${BLUE}→${RESET} Migrating: $PROJECT_DIR"
echo ""

# ── BACKUP ────────────────────────────────────────

BACKUP_DIR="${PROJECT_DIR}-backup-$TODAY"
cp -r "$PROJECT_DIR" "$BACKUP_DIR"
echo -e "${GREEN}✓${RESET} Backup created: $BACKUP_DIR"
echo -e "  (if anything goes wrong: cp -r $BACKUP_DIR $PROJECT_DIR)"
echo ""

cd "$PROJECT_DIR"

# ── DETECT EXISTING STATE ─────────────────────────

PM_NAME=$(grep -r "PM_NAME\|pm_name\|Aakash" OWNERS.md CLAUDE.md 2>/dev/null | head -1 | grep -o "Aakash[^|,)]*" | head -1 || echo "Aakash Dhar")
PM_EMAIL=$(grep -r "sorigin.com" OWNERS.md CLAUDE.md 2>/dev/null | grep -o "[a-z]*@sorigin.com" | head -1 || echo "aakash@sorigin.com")
CLIENT_NAME=$(grep -r "Client:" project.md 2>/dev/null | head -1 | sed 's/.*Client: //' | tr -d '*' | xargs || echo "Client")

echo -e "  Detected PM: $PM_NAME ($PM_EMAIL)"
echo -e "  Detected Client: $CLIENT_NAME"
echo ""

# Org details
echo -e "${BOLD}Delivering organisation (dashboard branding):${RESET}"
echo ""
echo -e "  1) BetaCraft  #E22A38"
echo -e "  2) Free Range #FF4E02"
echo -e "  3) Custom"
echo ""
read -p "Select [1/2/3] (default: 1): " ORG_CHOICE

case "${ORG_CHOICE:-1}" in
  2)
    ORG_NAME="Free Range"
    ORG_LOGO="https://freerange.com/hubfs/Free%20Range/Chicken.svg"
    ORG_COLOR="#FF4E02"
    ORG_EMAIL="aakash@freerangestudios.com"
    echo -e "${GREEN}✓${RESET} Free Range selected"
    ;;
  3)
    read -p "Organisation name:           " ORG_NAME
    read -p "Logo URL:                    " ORG_LOGO
    read -p "Primary colour (hex):        " ORG_COLOR
    read -p "Contact email:               " ORG_EMAIL
    ORG_NAME="${ORG_NAME:-BetaCraft}"
    ORG_LOGO="${ORG_LOGO:-https://betacraft.com/logo.svg}"
    ORG_COLOR="${ORG_COLOR:-#E22A38}"
    ORG_EMAIL="${ORG_EMAIL:-aakash@sorigin.com}"
    echo -e "${GREEN}✓${RESET} Custom org: $ORG_NAME"
    ;;
  *)
    ORG_NAME="BetaCraft"
    ORG_LOGO="https://betacraft.com/logo.svg"
    ORG_COLOR="#E22A38"
    ORG_EMAIL="aakash@sorigin.com"
    echo -e "${GREEN}✓${RESET} BetaCraft selected"
    ;;
esac
echo ""

# ── ADD MISSING DIRECTORIES ───────────────────────

echo -e "${BOLD}Adding missing directories...${RESET}"

python3 << PYEOF
import os
dirs = [
    "shared",
    "comms/attachments",
    "research/competitive",
    "research/technical",
    "research/client",
    "workspaces/aakash/scratch",
    "dashboard-versions",
    "_skills/session/session-start",
    "_skills/session/session-end",
    "_skills/ingestion/build-sow",
    "_skills/ingestion/intake-document",
    "_skills/maintenance/merge-review",
    "_skills/maintenance/update-links",
    "_skills/delivery/query-knowledge",
    ".obsidian",
]
for d in dirs:
    os.makedirs(d, exist_ok=True)
print("  All directories ready")
PYEOF

echo -e "${GREEN}✓${RESET} Directories added"

# ── ADD MISSING SHARED/ FILES ─────────────────────

echo -e "${BOLD}Adding missing shared/ files...${RESET}"

add_if_missing() {
  local dest="$1"
  local src="$TEMPLATE_DIR/$1"
  if [ ! -f "$dest" ] && [ -f "$src" ]; then
    cp "$src" "$dest"
    # Replace placeholders
    sed -i.bak \
      -e "s/\[\[PM_NAME\]\]/$PM_NAME/g" \
      -e "s/\[\[CLIENT_NAME\]\]/$CLIENT_NAME/g" \
      -e "s/\[\[PM_EMAIL\]\]/$PM_EMAIL/g" \
      -e "s/\[\[TODAY\]\]/$TODAY/g" \
      "$dest" 2>/dev/null && rm -f "$dest.bak"
    echo -e "  ${GREEN}+${RESET} $dest"
  else
    echo -e "  ${BLUE}→${RESET} $dest already exists — skipped"
  fi
}

add_if_missing "shared/PROJECT_INDEX.md"
add_if_missing "shared/DECISIONS.md"
add_if_missing "shared/HOTSHEET.md"
add_if_missing "shared/PROJECT_STRATEGY.md"
add_if_missing "shared/CONFLICTS.md"
add_if_missing "shared/VOCABULARY.md"
add_if_missing "OWNERS.md"
add_if_missing "client.md"
add_if_missing "reference/sow.md"
add_if_missing "reference/contract.md"
add_if_missing "requirements/_baseline.md"
add_if_missing "comms/summary.md"
add_if_missing "comms/todos.md"
add_if_missing "dashboard-versions/index.html"

# Workspace files
add_if_missing "workspaces/aakash/session-log.md"
add_if_missing "workspaces/aakash/proposed-decisions.md"
add_if_missing "workspaces/aakash/proposed-risks.md"

# Dashboard
if [ ! -f "dashboard.html" ]; then
  cp "$TEMPLATE_DIR/dashboard.html" "dashboard.html"
  echo -e "  ${GREEN}+${RESET} dashboard.html"
fi

echo -e "${GREEN}✓${RESET} Shared files added"

# Write org.json
if [ ! -f "org.json" ]; then
  cat > "org.json" << ORGJSON
{
  "name": "$ORG_NAME",
  "logo": "$ORG_LOGO",
  "primary": "$ORG_COLOR",
  "email": "$ORG_EMAIL"
}
ORGJSON
  echo -e "${GREEN}✓${RESET} org.json created ($ORG_NAME)"
else
  echo -e "${BLUE}→${RESET} org.json already exists — skipped (edit manually if needed)"
fi

# ── COPY ALL SKILLS ───────────────────────────────

echo -e "${BOLD}Updating skill library...${RESET}"

cp -r "$TEMPLATE_DIR/_skills/" "./_skills/" 2>/dev/null \
  && echo -e "${GREEN}✓${RESET} All 23 skills installed" \
  || echo -e "${AMBER}⚠${RESET} Skills copy had issues — check _skills/"

# ── ADD OBSIDIAN CONFIG ───────────────────────────

echo -e "${BOLD}Adding Obsidian config...${RESET}"

if [ ! -f ".obsidian/app.json" ]; then
  cp "$TEMPLATE_DIR/.obsidian/app.json" ".obsidian/app.json"
  cp "$TEMPLATE_DIR/.obsidian/community-plugins.json" ".obsidian/community-plugins.json"
  cp "$TEMPLATE_DIR/.obsidian/graph.json" ".obsidian/graph.json"
  echo -e "${GREEN}✓${RESET} Obsidian vault configured"
else
  echo -e "${BLUE}→${RESET} .obsidian/ already exists — skipped"
fi

# ── ADD FRONTMATTER TO EXISTING FILES ────────────

echo -e "${BOLD}Adding frontmatter to existing documents...${RESET}"

python3 << PYEOF
import os, re

def has_frontmatter(content):
    return content.startswith('---')

def add_frontmatter(filepath, fm):
    with open(filepath, 'r') as f:
        content = f.read()
    if has_frontmatter(content):
        return False
    with open(filepath, 'w') as f:
        f.write(fm + '\n' + content)
    return True

added = 0

# Requirements
for f in os.listdir('requirements'):
    if f.endswith('.md') and f != '_baseline.md':
        slug = f.replace('.md', '')
        req_id = slug.split('-')[0] if '-' in slug else slug
        fm = f"""---
type: requirement
id: {req_id}
status: unknown
authority: tier-2
date-modified: $TODAY
tags: [requirement]
---"""
        if add_frontmatter(f'requirements/{f}', fm):
            added += 1

# Deliverables
if os.path.exists('deliverables'):
    for f in os.listdir('deliverables'):
        if f.endswith('.md'):
            slug = f.replace('.md', '')
            del_id = slug.split('-')[0] if '-' in slug else slug
            fm = f"""---
type: deliverable
id: {del_id}
status: unknown
authority: tier-2
date-modified: $TODAY
tags: [deliverable]
---"""
            if add_frontmatter(f'deliverables/{f}', fm):
                added += 1

# Change log
if os.path.exists('change-log'):
    for f in os.listdir('change-log'):
        if f.endswith('.md'):
            date_match = re.match(r'(\d{4}-\d{2}-\d{2})', f)
            date = date_match.group(1) if date_match else '$TODAY'
            fm = f"""---
type: change-event
date: {date}
authority: tier-3
tags: [change-event]
---"""
            if add_frontmatter(f'change-log/{f}', fm):
                added += 1

# Meetings
if os.path.exists('comms/meetings'):
    for f in os.listdir('comms/meetings'):
        if f.endswith('.md'):
            date_match = re.match(r'(\d{4}-\d{2}-\d{2})', f)
            date = date_match.group(1) if date_match else '$TODAY'
            doc_type = 'transcript' if 'transcript' in f else 'meeting-summary'
            fm = f"""---
type: {doc_type}
date: {date}
authority: tier-3
tags: [meeting]
---"""
            if add_frontmatter(f'comms/meetings/{f}', fm):
                added += 1

print(f"  Added frontmatter to {added} files")
PYEOF

echo -e "${GREEN}✓${RESET} Frontmatter added to existing documents"

# ── UPDATE CLAUDE.MD ──────────────────────────────

echo -e "${BOLD}Updating CLAUDE.md...${RESET}"

if [ -f "CLAUDE.md" ]; then
  # Add Obsidian MCP section if not present
  grep -q "Obsidian MCP" CLAUDE.md 2>/dev/null || cat >> CLAUDE.md << CLAUDEEOF

---

## Obsidian Knowledge Graph

This project is connected to the Obsidian MCP server (obsidian-$PROJECT_SLUG).

Use the query-knowledge skill for retrieval across large document sets:
- "query: what did the client say about [topic]?"
- "query: full history of REQ-00N"
- "query: all decisions linked to [topic]"

The knowledge graph is abstracted — you never need to open Obsidian.
Cowork queries it automatically for complex retrieval tasks.

## Updated Skills

| Category | New Skills Added |
|---|---|
| Session | session-start (with drift detection) · session-end (with Reasoning) |
| Ingestion | build-sow · intake-document |
| Maintenance | merge-review · update-links |
| Delivery | query-knowledge |
CLAUDEEOF
  echo -e "${GREEN}✓${RESET} CLAUDE.md updated"
else
  cp "$TEMPLATE_DIR/CLAUDE.md" "CLAUDE.md"
  sed -i.bak \
    -e "s/\[\[PROJECT_NAME\]\]/$PROJECT_SLUG/g" \
    -e "s/\[\[PROJECT_SLUG\]\]/$PROJECT_SLUG/g" \
    -e "s/\[\[CLIENT_NAME\]\]/$CLIENT_NAME/g" \
    -e "s/\[\[PM_NAME\]\]/$PM_NAME/g" \
    -e "s/\[\[PM_EMAIL\]\]/$PM_EMAIL/g" \
    -e "s/\[\[TODAY\]\]/$TODAY/g" \
    "CLAUDE.md" && rm -f "CLAUDE.md.bak"
  echo -e "${GREEN}✓${RESET} CLAUDE.md created from template"
fi

# ── OBSIDIAN MCP CONFIG ───────────────────────────

echo -e "${BOLD}Connecting Obsidian MCP to Claude Desktop...${RESET}"

# Install MCP server
npm install -g obsidian-mcp-server -q 2>/dev/null \
  && echo -e "${GREEN}✓${RESET} obsidian-mcp-server installed" \
  || echo -e "${AMBER}⚠${RESET} Will use npx fallback"

if [ -f "$CLAUDE_CONFIG" ]; then
  cp "$CLAUDE_CONFIG" "$CLAUDE_CONFIG.backup-$TODAY"
  echo -e "${GREEN}✓${RESET} Config backed up"

  python3 << PYEOF
import json

config_path = "$CLAUDE_CONFIG"
project_dir = "$PROJECT_DIR"
project_slug = "$PROJECT_SLUG"

with open(config_path, 'r') as f:
    config = json.load(f)

if 'mcpServers' not in config:
    config['mcpServers'] = {}

mcp_key = f"obsidian-{project_slug}"

if mcp_key in config['mcpServers']:
    print(f"  Already exists: {mcp_key} — updating path")
else:
    print(f"  Adding: {mcp_key}")

config['mcpServers'][mcp_key] = {
    "command": "npx",
    "args": ["-y", "obsidian-mcp-server", project_dir]
}

with open(config_path, 'w') as f:
    json.dump(config, f, indent=2)
PYEOF

  echo -e "${GREEN}✓${RESET} Obsidian MCP added for $PROJECT_SLUG"

else
  python3 << PYEOF
import json, os
os.makedirs(os.path.dirname("$CLAUDE_CONFIG"), exist_ok=True)
config = {"mcpServers": {"obsidian-$PROJECT_SLUG": {"command": "npx", "args": ["-y", "obsidian-mcp-server", "$PROJECT_DIR"]}}}
with open("$CLAUDE_CONFIG", 'w') as f:
    json.dump(config, f, indent=2)
print("  Created claude_desktop_config.json")
PYEOF
  echo -e "${GREEN}✓${RESET} Claude Desktop config created"
fi

# ── GIT COMMIT ────────────────────────────────────

echo -e "${BOLD}Committing migration...${RESET}"

git add .
git commit -m "migrate: obsidian mcp + knowledge graph + new skills added $TODAY" -q \
  && echo -e "${GREEN}✓${RESET} Migration committed"

git push origin main -q 2>/dev/null \
  && echo -e "${GREEN}✓${RESET} Pushed to GitHub" \
  || echo -e "${AMBER}⚠${RESET} No remote configured — committed locally only"

# ── DONE ──────────────────────────────────────────

echo ""
echo -e "${BOLD}${GREEN}✓ Migration complete.${RESET}"
echo "─────────────────────────────────────────"
echo -e "  ${BOLD}Project:${RESET}  $PROJECT_SLUG"
echo -e "  ${BOLD}Location:${RESET} $PROJECT_DIR"
echo -e "  ${BOLD}Backup:${RESET}   $BACKUP_DIR"
echo -e "  ${BOLD}MCP key:${RESET}  obsidian-$PROJECT_SLUG"
echo ""
echo -e "${BOLD}What was added:${RESET}"
echo "  + Obsidian MCP knowledge graph"
echo "  + Frontmatter on all existing documents"
echo "  + shared/ governing layer (if missing)"
echo "  + 23 skills (session, ingestion, delivery, verification, dashboard)"
echo "  + workspace proposals (proposed-decisions, proposed-risks)"
echo "  + shared/VOCABULARY.md"
echo "  + shared/CONFLICTS.md"
echo "  + .obsidian/ vault config"
echo ""
echo -e "${BOLD}${AMBER}Action required:${RESET}"
echo -e "  1. ${BOLD}Restart Claude Desktop${RESET} to activate Obsidian MCP"
echo -e "  2. Open ${BLUE}$PROJECT_DIR${RESET} in Cowork"
echo -e "  3. Say: ${BOLD}\"start session\"${RESET} to verify everything works"
echo ""
echo "To migrate another project:"
echo "  bash migrate.sh ~/Documents/[other-project]"
echo ""
