# Baseline Requirements — [[PROJECT_NAME]]

**Authority:** Tier 1 — Canonical
**Locked:** [date — set when build-sow is approved]
**Source:** `reference/sow.md`
**Rule:** Never edit. All changes go through change-log/ with PM approval.

> Original requirements as agreed in the SOW.
> This is the ground truth for "what was originally promised."
> Post-SOW additions are tracked in requirements/REQ-*.md files
> and flagged as "Added post-SOW" in the dashboard.

---

## Original Requirements

[Populated by Cowork when build-sow skill is approved]

| ID | Requirement | Description |
|---|---|---|
| REQ-001 | [Title] | [From SOW] |

---

## Original Delivery Date

[From SOW]

---

## Original Fee

[From SOW]

---

## Explicitly Out of Scope

[From SOW — verbatim]
