# DECISIONS — [[PROJECT_NAME]]

**Authority:** Tier 2 — Operational
**Rule:** Append-only. Never edit existing entries. Never delete. Never reorder.
**Created:** [[TODAY]]

> Sequential decision log. Every significant decision gets a DEC number.
> Once logged — locked. This stops the team relitigating settled questions.
> Reference decisions by ID in all other documents.

---

## What gets a DEC number

- Architecture and technology choices
- Scope decisions (in or out)
- Commercial terms agreed
- Vocabulary and naming conventions locked
- Responsibility boundaries settled
- Any decision that would cause confusion if unmade

---

<!-- DECISIONS BELOW — APPEND ONLY — DO NOT EDIT ABOVE ENTRIES -->
