# CONFLICTS — [[PROJECT_NAME]]

**Authority:** Tier 2 — Operational
**Maintained by:** Cowork — never silently resolves conflicts
**Rule:** PM resolves all conflicts. Nothing in this file is acted on until PM decides.
**Created:** [[TODAY]]

> When Cowork finds a conflict between a proposed change and an existing document,
> it stops and writes here instead of acting. PM reads this and decides.
> Resolved conflicts are marked closed but never deleted.

---

## Open Conflicts

*No conflicts yet.*

---

## Resolved Conflicts

*None yet.*

---

<!-- CONFLICT FORMAT:

## CONFLICT-001 — [Date]
**Between:** [File A] vs [File B]
**Nature:** [What the conflict is]
**Proposed change:** [What Cowork was going to do]
**Blocked by:** [Authority rule that triggered the conflict]
**Resolution needed from:** [[PM_NAME]]
**Status:** Open / Resolved — [resolution description] — [date]

-->
