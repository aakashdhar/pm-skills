# HOTSHEET — [[PROJECT_NAME]]

**Authority:** Tier 2 — Operational
**Maintained by:** Cowork — updated automatically after every transcript and comms sync
**Last Updated:** [[TODAY]]

---

## 🔴 Blocking

<!-- Items actively blocking delivery -->

*Nothing blocking yet.*

---

## 🟡 Needs Attention

<!-- Items needing resolution soon -->

*Nothing pending yet.*

---

## 🔵 Watching

<!-- Risks being monitored — not urgent yet -->

*Nothing being watched yet.*

---

## ✅ Resolved

<!-- Closed items — kept for reference, never deleted -->
