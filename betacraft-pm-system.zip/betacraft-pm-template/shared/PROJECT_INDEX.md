# PROJECT INDEX — [[PROJECT_NAME]]

**Authority:** Tier 2 — Operational
**Rule:** Must be current at all times. Updated at end of every session.
**Last Updated:** [[TODAY]]

> The master map of this project. Read this first every session.
> If this file is stale — run session-end to catch up.

---

## Project State

**Status:** 🟢 Green
**Phase:** Discovery
**Days elapsed:** 0
**Days to delivery:** [TBD]
**Last session:** [[TODAY]]

---

## Open Questions

| # | Question | Raised | Owner |
|---|---|---|---|
| — | — | — | — |

---

## Decisions (latest 5)

| ID | Decision | Date |
|---|---|---|
| — | — | — |

*Full log: `shared/DECISIONS.md`*

---

## Blocking Items

| Item | Since | Owner |
|---|---|---|
| — | — | — |

*Full hotsheet: `shared/HOTSHEET.md`*

---

## Core Files

| File | Authority | Description | Last Updated |
|---|---|---|---|
| `CLAUDE.md` | — | Cowork brain | [[TODAY]] |
| `OWNERS.md` | — | Ownership map | [[TODAY]] |
| `client.md` | Tier 2 | Client context | [[TODAY]] |
| `project.md` | Tier 2 | Current state | [[TODAY]] |
| `shared/PROJECT_INDEX.md` | Tier 2 | This file | [[TODAY]] |
| `shared/DECISIONS.md` | Tier 2 | Decision log | [[TODAY]] |
| `shared/HOTSHEET.md` | Tier 2 | Open items | [[TODAY]] |
| `shared/PROJECT_STRATEGY.md` | Tier 2 | Direction | [[TODAY]] |
| `shared/CONFLICTS.md` | Tier 2 | Conflicts queue | [[TODAY]] |
| `shared/VOCABULARY.md` | Tier 1 | Canonical terms | [[TODAY]] |

---

## Reference — Tier 1 Canonical

| File | Description | Locked |
|---|---|---|
| `reference/sow.md` | Statement of Work — original agreement | [date] |
| `reference/contract.md` | Signed contract | [date] |
| `requirements/_baseline.md` | Original requirements from SOW | [date] |

---

## Requirements

| File | Title | Status |
|---|---|---|
| `requirements/_baseline.md` | Baseline from SOW | Locked |

---

## Deliverables

| File | Title | Status |
|---|---|---|
| — | — | — |

---

## Change Log

| File | Description |
|---|---|
| — | — |

---

## Communications

| File | Description |
|---|---|
| `comms/summary.md` | Running relationship narrative |
| `comms/todos.md` | Action items from all comms |

---

## Architecture

| File | Description |
|---|---|
| `architecture/overview.md` | System design and stack |

---

## Research

| File | Author | Topic |
|---|---|---|
| — | — | — |

---

## Dashboard

| File | Description |
|---|---|
| `dashboard.html` | Latest published dashboard |
| `dashboard-versions/index.html` | Version history |
