# VOCABULARY — [[PROJECT_NAME]]

**Authority:** Tier 1 — Canonical
**Source:** Extracted from `reference/sow.md` by build-sow skill
**Locked:** [date — set when build-sow is approved]
**Rule:** These terms must be used consistently across all documents,
          transcripts, and communications. Deviations are flagged as drift.

> Canonical vocabulary for this project.
> Every document Cowork writes uses these exact terms.
> Every transcript Cowork processes is checked against these terms.
> Drift from these terms is flagged — never silently corrected.

---

## Project Terms

| Canonical Term | What it means | Do not use |
|---|---|---|
| [Term] | [Definition] | [Alternative terms to avoid] |

---

## People & Roles

| Canonical Name | Role | Do not use |
|---|---|---|
| [[CLIENT_NAME]] | Client · Product Owner | [variants] |
| [[PM_NAME]] | Project Manager | [variants] |

---

## Technical Terms

| Canonical Term | What it means | Do not use |
|---|---|---|
| [Term] | [Definition] | [variants] |

---

## Process Terms

| Canonical Term | What it means | Do not use |
|---|---|---|
| [Term] | [Definition] | [variants] |

---

## Notes

[Any additional vocabulary context or naming conventions.]
