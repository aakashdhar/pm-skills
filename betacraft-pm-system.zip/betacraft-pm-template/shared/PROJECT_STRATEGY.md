# PROJECT STRATEGY — [[PROJECT_NAME]]

**Authority:** Tier 2 — Operational
**Inherits from:** `reference/sow.md`
**Created:** [[TODAY]]

> Strategic direction, goals, and constraints for this project.
> Drafted by Cowork from SOW after build-sow is approved.
> Updated when significant strategic decisions are made.

---

## Vision

[What does success look like at the end of this engagement?]

---

## Goals

1. [Primary goal]
2. [Secondary goal]

---

## Constraints

- [Timeline constraint]
- [Budget constraint]
- [Technical constraint]

---

## Key Dependencies

- [External dependency and owner]

---

## Relationship to Other Work

[Is this part of a larger engagement? Phase context?]

---

## Notes

[Anything else that informs strategic direction.]
