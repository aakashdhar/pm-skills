# Comms Summary — [[PROJECT_NAME]]

**Authority:** Tier 3 — Archive
**Maintained by:** Cowork — updated after every comms sync
**Last Updated:** [[TODAY]]

> Running plain-English narrative of the client relationship.
> Not a list of events — a narrative a new PM could read to understand
> the relationship history without hunting through emails.

---

[No communications recorded yet. Project started [[TODAY]].]
