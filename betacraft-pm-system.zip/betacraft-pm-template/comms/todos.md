# Comms Action Items — [[PROJECT_NAME]]

**Authority:** Tier 3 — Archive
**Maintained by:** Cowork — updated after every transcript and comms sync
**Last Updated:** [[TODAY]]

> Action items that came out of client communications.
> Different from HOTSHEET — these are specific commitments made in comms.
> Completed items stay — never deleted.

---

## Open

*No action items yet.*

---

## Completed

*None yet.*
